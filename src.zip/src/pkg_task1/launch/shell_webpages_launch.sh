#!/bin/bash
URL1="http://www.hivemq.com/demos/websocket-client/"
URL2="https://docs.google.com/spreadsheets/d/1Cx7cgwB9NZCrljAtYBdpSwoumBAfOm3_9Pser4Eahng/edit#gid=0"
firefox -new-window $URL1 $URL2




